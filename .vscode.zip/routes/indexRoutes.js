const express = require("express");
const router = express.Router();
const { registerUser } = require("../controller/auth_controller");



// Home route
router.get("/", async (req, res) => {
  try {
    // const posts = await Post.find({}).populate("author", "username");
    // const user = await User.find({}).populate( "username");
    res.render("index");
  } catch (error) {
    res.status(500).json({ message: "Error fetching posts", error });
  }
});

// Sign-in route
router.get("/signin", (req, res) => {
  try {
    res.render("login");
  } catch (error) {
    res.status(500).json({ message: "Error fetching posts", error });
  }
});
router.get("/blogs", (req, res) => {
  try {
    res.render("blogs");
  } catch (error) {
    res.status(500).json({ message: "Error fetching posts", error });
  }
});

// Register route
router.get("/register", (req, res) => {
  res.render("register");
});



// Registration route
router.post('/register', registerUser);



router.get('/blogs', function (req, res, next) {
  res.render('blogs', { title: 'Express' });
});

module.exports = router;
